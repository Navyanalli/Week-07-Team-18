"""Simple baseline forecasts that every model must be compared with.

Each function takes the daily target series and returns the forecast for each
day using only earlier days.
"""

from __future__ import annotations

import pandas as pd


def persistence(target: pd.Series) -> pd.Series:
    """Tomorrow = today: the forecast for day D is the value on D-1."""
    return target.shift(1)


def seasonal_naive(target: pd.Series, season: int = 7) -> pd.Series:
    """The forecast for day D is the value on the same weekday last week."""
    return target.shift(season)


def moving_average(target: pd.Series, window: int = 7) -> pd.Series:
    """The forecast for day D is the mean of the previous ``window`` days."""
    return target.shift(1).rolling(window, min_periods=window).mean()


BASELINES = {
    "persistence": persistence,
    "seasonal_naive_7d": seasonal_naive,
    "moving_average_7d": moving_average,
}
