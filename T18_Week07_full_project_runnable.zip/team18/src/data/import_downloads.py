"""Copy NESO CSVs downloaded in a browser into a dated snapshot folder.

Use this when the NESO site cannot be reached from a script. Save the files into
data/incoming/ (or pass another folder), then run:

    python -m src.data.import_downloads [folder]

Files are sorted by name into the same layout download_data.py creates, with a
metadata.json (file, source page, import time, bytes, rows, SHA-256).
"""

from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from src.config import ROOT, get_logger, load_config, project_path
from src.data.download_data import sha256_of

log = get_logger(__name__)

PATTERNS = {
    "constraint_breakdown": "constraint-breakdown-*.csv",
    "generation_mix": "df_fuel_ckan*.csv",
    "day_ahead_flows": "day-ahead-constraint*.csv",
}


def import_folder(incoming: Path) -> Path:
    """Copy recognised NESO CSVs from ``incoming`` into a new snapshot folder.

    Raises
    ------
    FileNotFoundError
        If no recognised NESO files are found.
    """
    cfg = load_config()
    stamp = datetime.now().strftime("%Y%m%d")
    snapshot = project_path(f"{cfg['paths']['raw']}/snapshot_{stamp}")
    found = 0
    for name, pattern in PATTERNS.items():
        files = sorted(incoming.glob(pattern))
        if not files:
            log.warning("No %s files (%s) in %s", name, pattern, incoming)
            continue
        folder = snapshot / name
        folder.mkdir(parents=True, exist_ok=True)
        meta = {"dataset": name, "page": cfg["neso"]["datasets"][name]["page"],
                "licence": "NESO Open Data Licence", "attribution": cfg["neso"]["attribution"],
                "files": []}
        for f in files:
            dest = folder / f.name
            shutil.copy2(f, dest)
            with dest.open("rb") as fh:
                rows = max(sum(1 for _ in fh) - 1, 0)
            meta["files"].append({
                "file": f.name,
                "imported_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "bytes": dest.stat().st_size, "rows": rows, "sha256": sha256_of(dest)})
            found += 1
        (folder / "metadata.json").write_text(json.dumps(meta, indent=2))
        log.info("%s: %d files -> %s", name, len(files), folder)
    if not found:
        raise FileNotFoundError(f"No NESO CSV files found in {incoming}")
    return snapshot


if __name__ == "__main__":
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "incoming"
    import_folder(src)
