"""Run the first stage of the pipeline on the latest data snapshot.

Steps: load and clean D1-D3 -> data quality report -> daily features ->
modelling table -> EDA summary -> baseline scores on validation and test.

Usage:
    python -m src.run_pipeline
"""

from __future__ import annotations

import pandas as pd

from src.config import ROOT, get_logger, load_config, project_path
from src.data import quality
from src.data.load import latest_snapshot, load_constraint_breakdown, load_day_ahead, load_generation_mix
from src.evaluation.metrics import diebold_mariano, mae, mase, rmse
from src.features.build_features import (
    aggregate_day_ahead_daily,
    aggregate_generation_daily,
    build_model_table,
    split_by_date,
)
from src.models.baselines import BASELINES

log = get_logger("pipeline")


def financial_year(d: pd.Timestamp) -> str:
    """Return the NESO financial year label (April to March), e.g. 2017-18."""
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start}-{str(start + 1)[-2:]}"


def eda_summary(table: pd.DataFrame) -> pd.DataFrame:
    """Per financial year: days, sign of thermal volume and size statistics."""
    t = table.dropna(subset=["thermal_volume_signed"]).copy()
    t["fy"] = [financial_year(d) for d in t.index]
    v = t["thermal_volume_signed"]
    return t.assign(neg=v < 0, zero=v == 0, pos=v > 0).groupby("fy").agg(
        days=("target", "size"),
        negative_days=("neg", "sum"),
        zero_days=("zero", "sum"),
        positive_days=("pos", "sum"),
        target_mean_mwh=("target", "mean"),
        target_median_mwh=("target", "median"),
        target_max_mwh=("target", "max"),
    ).round(1)


def score_baselines(table: pd.DataFrame, parts: dict) -> pd.DataFrame:
    """Score every baseline on the validation and test periods."""
    y_train = parts["train"]["target"]
    preds = {name: fn(table["target"]) for name, fn in BASELINES.items()}
    rows = []
    for split in ["val", "test"]:
        idx = parts[split].index
        # score every baseline on the same days: target and all forecasts present
        common = table.loc[idx, "target"].notna()
        for p in preds.values():
            common &= p.loc[idx].notna()
        idx = idx[common.to_numpy()]
        y = table.loc[idx, "target"]
        if len(idx) == 0:
            log.warning("No target data in %s period yet", split)
            continue
        for name, p in preds.items():
            stat, pval = diebold_mariano(y, p.loc[idx], preds["persistence"].loc[idx])
            rows.append({
                "split": split, "model": name, "days": int(y.notna().sum()),
                "MAE_MWh": round(mae(y, p.loc[idx]), 1),
                "RMSE_MWh": round(rmse(y, p.loc[idx]), 1),
                "MASE": round(mase(y, p.loc[idx], y_train), 3),
                "DM_vs_persistence_p": round(pval, 4) if name != "persistence" else None,
            })
    return pd.DataFrame(rows)


def main() -> None:
    cfg = load_config()
    snap = latest_snapshot(ROOT / cfg["paths"]["raw"])
    log.info("Using snapshot %s", snap.name)
    results = project_path(cfg["paths"]["results"])
    processed = project_path(cfg["paths"]["processed"])

    d1 = load_constraint_breakdown(snap / "constraint_breakdown")
    d2 = load_generation_mix(snap / "generation_mix")
    d3_dir = snap / "day_ahead_flows"
    d3 = load_day_ahead(d3_dir, cfg["data"]["limit_sentinel"]) if d3_dir.exists() else None

    dq = quality.run_all(d1, d2, d3)
    dq.to_csv(results / "dq_report.csv", index=False)
    log.info("Data quality:\n%s", dq.to_string(index=False))
    if (dq["status"] == quality.FAIL).any():
        log.error("Data quality FAIL found - see results/dq_report.csv")

    gen_daily = aggregate_generation_daily(
        d2, cfg["data"]["min_periods_per_day"], cfg["data"]["max_interpolate_periods"])
    da_daily = aggregate_day_ahead_daily(d3) if d3 is not None else None
    table = build_model_table(
        d1, gen_daily, da_daily,
        tuple(cfg["features"]["lags"]), tuple(cfg["features"]["rolling_windows"]))
    stamp = snap.name.replace("snapshot_", "")
    table.to_parquet(processed / f"daily_model_table_{stamp}.parquet")
    log.info("Model table: %d days x %d columns", *table.shape)

    eda = eda_summary(table)
    eda.to_csv(results / "eda_by_financial_year.csv")
    log.info("Target by financial year:\n%s", eda.to_string())

    parts = split_by_date(table, cfg["split"])
    scores = score_baselines(table, parts)
    scores.to_csv(results / "baseline_metrics.csv", index=False)
    log.info("Baselines:\n%s", scores.to_string(index=False))


if __name__ == "__main__":
    main()
