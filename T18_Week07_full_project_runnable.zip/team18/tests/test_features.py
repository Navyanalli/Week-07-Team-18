"""Unit and leakage tests for daily aggregation, features and the split."""

import numpy as np
import pandas as pd
import pytest

from src.features.build_features import (
    aggregate_generation_daily,
    build_model_table,
    split_by_date,
    to_uk_date,
)


def half_hours(start_utc: str, end_utc: str, wind: float = 100.0) -> pd.DataFrame:
    t = pd.date_range(start_utc, end_utc, freq="30min", inclusive="left", tz="UTC")
    return pd.DataFrame({"DATETIME": t, "WIND": wind, "WIND_EMB": 0.0, "GENERATION": 1000.0})


def daily_target(days: int, start: str = "2024-01-01") -> pd.DataFrame:
    dates = pd.date_range(start, periods=days, freq="D")
    return pd.DataFrame({"date": dates, "thermal_volume_signed": -np.arange(days, dtype=float),
                         "thermal_cost": np.arange(days, dtype=float)})


def test_to_uk_date_summer_late_evening_is_next_day():
    ts = pd.Series(pd.to_datetime(["2024-07-01 23:30"], utc=True))
    assert to_uk_date(ts).iloc[0] == pd.Timestamp("2024-07-02")


def test_to_uk_date_winter_matches_utc_and_leap_day():
    ts = pd.Series(pd.to_datetime(["2024-02-29 12:00"], utc=True))
    assert to_uk_date(ts).iloc[0] == pd.Timestamp("2024-02-29")


def test_normal_day_gives_one_row_with_correct_mean():
    d2 = half_hours("2024-01-10 00:00", "2024-01-11 00:00", wind=200.0)
    daily = aggregate_generation_daily(d2)
    assert len(daily) == 1
    assert daily["n_periods"].iloc[0] == 48
    assert daily["wind_mean_mw"].iloc[0] == pytest.approx(200.0)
    assert daily["wind_share_pct"].iloc[0] == pytest.approx(20.0)


@pytest.mark.parametrize("start,end,expected", [
    # spring forward: UK day 31 Mar 2024 runs 00:00 UTC to 23:00 UTC -> 46 periods
    ("2024-03-31 00:00", "2024-03-31 23:00", 46),
    # autumn back: UK day 27 Oct 2024 runs 23:00 UTC 26 Oct to 00:00 UTC 28 Oct -> 50 periods
    ("2024-10-26 23:00", "2024-10-28 00:00", 50),
])
def test_clock_change_days_keep_46_or_50_periods(start, end, expected):
    daily = aggregate_generation_daily(half_hours(start, end))
    assert expected in daily["n_periods"].tolist()


def test_partial_day_is_dropped():
    d2 = half_hours("2024-01-10 00:00", "2024-01-10 12:00")
    assert aggregate_generation_daily(d2).empty


def test_small_gap_is_interpolated_but_large_gap_drops_day():
    d2 = half_hours("2024-01-10 00:00", "2024-01-11 00:00")
    small = d2.drop(index=[10, 11])
    assert aggregate_generation_daily(small)["n_periods"].iloc[0] == 48
    large = d2.drop(index=range(10, 20))
    assert aggregate_generation_daily(large).empty


def test_target_is_size_of_volume_and_lags_shift_by_one():
    gen = aggregate_generation_daily(half_hours("2024-01-01 00:00", "2024-01-15 00:00"))
    t = build_model_table(daily_target(14), gen)
    assert (t["target"] >= 0).all()
    assert t.loc["2024-01-05", "target_lag1"] == t.loc["2024-01-04", "target"]
    assert np.isnan(t["target_lag1"].iloc[0])  # first row empty, not zero


def test_no_leakage_changing_today_does_not_change_todays_features():
    gen = aggregate_generation_daily(half_hours("2024-01-01 00:00", "2024-01-15 00:00"))
    d1 = daily_target(14)
    base = build_model_table(d1, gen)
    d1_changed = d1.copy()
    d1_changed.loc[d1_changed["date"] == "2024-01-10", "thermal_volume_signed"] = -1e9
    changed = build_model_table(d1_changed, gen)
    feats = [c for c in base.columns if c not in ("target", "thermal_volume_signed", "thermal_cost")]
    pd.testing.assert_frame_equal(base.loc[:"2024-01-10", feats], changed.loc[:"2024-01-10", feats])


def test_cheat_feature_is_caught():
    """A deliberately leaky feature (today's target) must fail the leakage check."""
    gen = aggregate_generation_daily(half_hours("2024-01-01 00:00", "2024-01-15 00:00"))
    t = build_model_table(daily_target(14), gen)
    t["cheat"] = t["target"]
    corr_lag0 = t["cheat"].corr(t["target"])
    assert corr_lag0 == pytest.approx(1.0)  # identical to the target -> leakage


def test_split_has_one_day_gap_and_no_overlap():
    idx = pd.date_range("2023-01-01", "2026-04-30", freq="D")
    table = pd.DataFrame({"target": 1.0}, index=idx)
    split = {"train_end": "2024-03-31", "val_start": "2024-04-02", "val_end": "2025-03-31",
             "test_start": "2025-04-02", "test_end": "2026-03-31"}
    p = split_by_date(table, split)
    assert p["train"].index.max() < p["val"].index.min() - pd.Timedelta(days=1)
    assert p["val"].index.max() < p["test"].index.min() - pd.Timedelta(days=1)
    assert p["train"].index.intersection(p["test"].index).empty


def test_split_out_of_order_raises():
    with pytest.raises(ValueError):
        split_by_date(pd.DataFrame(), {"train_end": "2025-01-01", "val_start": "2024-01-01",
                                       "val_end": "2024-06-01", "test_start": "2025-02-01",
                                       "test_end": "2025-03-01"})
