"""Unit tests for metrics and baselines (hand-calculated values)."""

import numpy as np
import pandas as pd
import pytest

from src.evaluation.metrics import diebold_mariano, mae, mase, rmse, skill_score
from src.models.baselines import moving_average, persistence, seasonal_naive


def test_mae_and_rmse_hand_values():
    y, p = [1, 2, 3], [2, 2, 5]
    assert mae(y, p) == pytest.approx(1.0)
    assert rmse(y, p) == pytest.approx(np.sqrt(5 / 3))


def test_metrics_ignore_missing_values():
    assert mae([1, np.nan, 3], [1, 5, 4]) == pytest.approx(0.5)


def test_length_mismatch_raises():
    with pytest.raises(ValueError):
        mae([1, 2], [1, 2, 3])


def test_mase_of_persistence_on_training_data_is_one():
    y = pd.Series([3.0, 5.0, 4.0, 8.0, 6.0])
    p = persistence(y)
    assert mase(y[1:], p[1:], y) == pytest.approx(1.0)


def test_skill_score_zero_for_same_forecast():
    assert skill_score([1, 2, 3], [1, 1, 1], [1, 1, 1]) == pytest.approx(0.0)


def test_diebold_mariano_identical_forecasts():
    stat, p = diebold_mariano([1, 2, 3, 4], [1, 2, 3, 3], [1, 2, 3, 3])
    assert stat == 0.0 and p == 1.0


def test_persistence_and_seasonal_naive():
    y = pd.Series(range(10), dtype=float)
    assert persistence(y).iloc[5] == 4
    assert seasonal_naive(y).iloc[8] == 1
    assert np.isnan(seasonal_naive(y).iloc[6])


def test_moving_average_uses_previous_days_only():
    y = pd.Series(range(10), dtype=float)
    assert moving_average(y, 3).iloc[3] == pytest.approx(1.0)  # mean of 0, 1, 2


def test_diebold_mariano_handles_different_missing_days():
    y = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
    a = [np.nan, 2.5, 3.0, 4.5, 5.0, 6.5]
    b = [np.nan, np.nan, 2.0, 4.0, 6.0, 5.0]
    stat, p = diebold_mariano(y, a, b)
    assert 0.0 <= p <= 1.0


def test_one_missing_day_is_warn_not_fail():
    from src.data.quality import check_constraint_breakdown
    dates = pd.date_range("2024-01-01", periods=200, freq="D").delete(50)
    d1 = pd.DataFrame({"date": dates, "thermal_volume_signed": -1.0})
    assert check_constraint_breakdown(d1)[0]["status"] == "WARN"
