"""Load and clean the three NESO datasets from a snapshot folder.

D1 constraint breakdown: one row per day, all yearly files combined.
D2 generation mix: half-hourly, DATETIME in UTC.
D3 day-ahead flows and limits: half-hourly per constraint group, local GB time.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

from src.config import get_logger

log = get_logger(__name__)


def snake(name: str) -> str:
    """Turn a column header such as 'Thermal Volume (MWh)' into 'thermal_volume_mwh'."""
    s = re.sub(r"[^0-9a-zA-Z]+", "_", str(name).strip().lstrip("﻿")).strip("_")
    return s.lower()


def find_column(columns: list[str], *keywords: str, exclude: tuple[str, ...] = ()) -> str:
    """Return the single column whose name contains every keyword.

    Raises
    ------
    KeyError
        If no column, or more than one column, matches.
    """
    hits = [
        c for c in columns
        if all(k in c.lower() for k in keywords) and not any(x in c.lower() for x in exclude)
    ]
    if len(hits) != 1:
        raise KeyError(f"Expected one column containing {keywords}, found {hits} in {columns}")
    return hits[0]


def latest_snapshot(raw_dir: Path) -> Path:
    """Return the newest data/raw/snapshot_YYYYMMDD folder."""
    snaps = sorted(p for p in raw_dir.glob("snapshot_*") if p.is_dir())
    if not snaps:
        raise FileNotFoundError(
            f"No snapshot in {raw_dir}. Run: python -m src.data.download_data"
        )
    return snaps[-1]


def parse_dates(values: pd.Series) -> pd.Series:
    """Parse dates written as 2017-04-01, 01/04/2017 or with a time part."""
    text = values.astype(str).str.strip()
    dayfirst = text.str.contains(r"^\d{1,2}/\d{1,2}/\d{4}", regex=True).mean() > 0.5
    return pd.to_datetime(text, format="mixed", dayfirst=dayfirst, errors="coerce")


def load_constraint_breakdown(folder: Path) -> pd.DataFrame:
    """Combine all yearly D1 files into one daily table.

    Returns columns ``date``, ``thermal_volume_signed`` (MWh), ``thermal_cost``
    and every other original column in snake_case. Duplicate dates keep the
    row from the most recent file.

    Raises
    ------
    FileNotFoundError
        If the folder holds no CSV files.
    """
    files = sorted(folder.glob("*.csv*"))
    if not files:
        raise FileNotFoundError(f"No constraint breakdown CSVs in {folder}")
    frames = []
    for f in files:
        df = pd.read_csv(f, encoding="utf-8-sig")
        df.columns = [snake(c) for c in df.columns]
        df["source_file"] = f.name
        frames.append(df)
    df = pd.concat(frames, ignore_index=True)
    cols = list(df.columns)
    date_col = find_column(cols, "date")
    vol_col = find_column(cols, "thermal", "volume")
    cost_col = find_column(cols, "thermal", "cost")
    df["date"] = parse_dates(df[date_col]).dt.normalize()
    bad = df["date"].isna().sum()
    if bad:
        log.warning("D1: %d rows with unreadable dates dropped", bad)
        df = df.dropna(subset=["date"])
    df["thermal_volume_signed"] = pd.to_numeric(df[vol_col], errors="coerce")
    df["thermal_cost"] = pd.to_numeric(df[cost_col], errors="coerce")
    before = len(df)
    df = df.sort_values(["date", "source_file"]).drop_duplicates("date", keep="last")
    if before != len(df):
        log.warning("D1: %d duplicate dates removed (kept latest file)", before - len(df))
    log.info("D1: %d days from %s to %s (%d files)",
             len(df), df["date"].min().date(), df["date"].max().date(), len(files))
    return df.reset_index(drop=True)


def load_generation_mix(folder: Path) -> pd.DataFrame:
    """Load the half-hourly generation mix with DATETIME as UTC timestamps."""
    files = sorted(folder.glob("*.csv*"))
    if not files:
        raise FileNotFoundError(f"No generation mix CSV in {folder}")
    df = pd.read_csv(files[0], encoding="utf-8-sig")
    if "DATETIME" not in df.columns:
        raise KeyError(f"DATETIME column missing in {files[0].name}")
    df["DATETIME"] = pd.to_datetime(df["DATETIME"], utc=True, format="mixed")
    df = df.sort_values("DATETIME").drop_duplicates("DATETIME", keep="last")
    log.info("D2: %d half-hours from %s to %s", len(df), df["DATETIME"].min(), df["DATETIME"].max())
    return df.reset_index(drop=True)


def load_day_ahead(folder: Path, sentinel: float = 99999) -> pd.DataFrame:
    """Load and clean the day-ahead constraint flows and limits.

    Cleaning: parse mixed timestamp formats (local GB time), remove duplicate
    (group, timestamp) rows keeping the last, set the 99999 "no limit" value and
    zero limits to missing, and add ``utilisation`` = |flow| / limit.
    """
    files = sorted(folder.glob("*.csv*"))
    if not files:
        raise FileNotFoundError(f"No day-ahead CSV in {folder}")
    df = pd.read_csv(files[0], encoding="utf-8-sig")
    df.columns = [snake(c) for c in df.columns]
    cols = list(df.columns)
    group_col = find_column(cols, "group") if any("group" in c for c in cols) else find_column(cols, "constraint")
    time_col = find_column(cols, "date")
    limit_col = find_column(cols, "limit")
    flow_col = find_column(cols, "flow")
    out = pd.DataFrame({
        "group": df[group_col].astype(str).str.strip(),
        "timestamp_local": pd.to_datetime(df[time_col].astype(str).str.strip(), format="mixed", errors="coerce"),
        "limit_mw": pd.to_numeric(df[limit_col], errors="coerce"),
        "flow_mw": pd.to_numeric(df[flow_col], errors="coerce"),
    })
    n_nat = out["timestamp_local"].isna().sum()
    if n_nat:
        log.warning("D3: %d unreadable timestamps dropped", n_nat)
        out = out.dropna(subset=["timestamp_local"])
    before = len(out)
    out = out.drop_duplicates(["group", "timestamp_local"], keep="last")
    log.info("D3: %d duplicate (group, timestamp) rows removed", before - len(out))
    n_sent = int((out["limit_mw"] >= sentinel).sum())
    n_zero = int((out["limit_mw"] == 0).sum())
    out.loc[(out["limit_mw"] >= sentinel) | (out["limit_mw"] == 0), "limit_mw"] = np.nan
    log.info("D3: %d sentinel and %d zero limits set to missing", n_sent, n_zero)
    out["utilisation"] = out["flow_mw"].abs() / out["limit_mw"]
    out["date"] = out["timestamp_local"].dt.normalize()
    return out.sort_values(["timestamp_local", "group"]).reset_index(drop=True)
