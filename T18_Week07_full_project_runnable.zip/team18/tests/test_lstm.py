"""Tests for the LSTM data preparation and model."""

import numpy as np
import pandas as pd
import pytest

torch = pytest.importorskip("torch")

from src.models.lstm import (  # noqa: E402
    LSTMConfig,
    LSTMRegressor,
    Scaler,
    make_sequences,
    make_target,
    predict,
    prepare_inputs,
    to_mwh,
    train_lstm,
)


def toy(n=60):
    idx = pd.date_range("2024-01-01", periods=n, freq="D")
    x = pd.DataFrame({"a": np.arange(n, dtype=float), "b": 1.0}, index=idx)
    y = pd.Series(np.arange(n, dtype=float) * 10, index=idx)
    return x, y


def test_window_ends_on_target_day_and_holds_only_inputs():
    x, y = toy()
    xs, ys, dates = make_sequences(x, y, x.index, window=5)
    assert xs.shape == (56, 5, 2)
    assert dates[0] == x.index[4]
    assert ys[0] == y.iloc[4]
    assert xs[0, -1, 0] == x["a"].iloc[4]  # last row of the window is the target day's inputs


def test_windows_with_missing_values_are_dropped():
    x, y = toy()
    x.iloc[10, 0] = np.nan
    _, _, dates = make_sequences(x, y, x.index, window=5)
    assert x.index[10] not in dates and x.index[14] not in dates and x.index[15] in dates


def test_prepare_inputs_logs_volumes_and_checks_columns():
    t = pd.DataFrame({"target_lag1": [0.0, np.e - 1], "wind": [1.0, 2.0]})
    out = prepare_inputs(t, ["target_lag1", "wind"], relative=False)
    assert out["target_lag1"].tolist() == pytest.approx([0.0, 1.0])
    with pytest.raises(KeyError):
        prepare_inputs(t, ["missing_col"], relative=False)


def test_scaler_uses_training_statistics():
    train = pd.DataFrame({"a": [1.0, 3.0]})
    s = Scaler.fit(train)
    assert s.transform(pd.DataFrame({"a": [2.0]}))["a"].iloc[0] == pytest.approx(0.0)


def test_model_output_shape_and_non_negative_predictions():
    model = LSTMRegressor(n_features=3, hidden=8, layers=1)
    x = np.random.default_rng(0).normal(size=(4, 7, 3)).astype(np.float32)
    assert model(torch.from_numpy(x)).shape == (4,)
    assert (predict(model, x, y_mean=5.0, y_std=1.0) >= 0).all()


def test_training_is_reproducible_with_same_seed():
    rng = np.random.default_rng(0)
    x = rng.normal(size=(40, 5, 2)).astype(np.float32)
    y = rng.normal(size=40).astype(np.float32)
    cfg = LSTMConfig(hidden=8, layers=1, max_epochs=3, batch_size=16)
    m1, _ = train_lstm(x, y, x, y, cfg)
    m2, _ = train_lstm(x, y, x, y, cfg)
    p1 = predict(m1, x, 0.0, 1.0)
    p2 = predict(m2, x, 0.0, 1.0)
    assert np.allclose(p1, p2)


def test_relative_target_round_trips_to_mwh():
    t = pd.DataFrame({"target": [100.0, 5000.0], "target_roll7_mean": [50.0, 4000.0]})
    z = make_target(t)
    level = np.log1p(t["target_roll7_mean"]).to_numpy()
    assert to_mwh(z.to_numpy(), level) == pytest.approx(t["target"].to_numpy())


def test_relative_inputs_ignore_a_constant_level_shift():
    base = pd.DataFrame({"target_lag1": [100.0, 200.0], "target_roll7_mean": [150.0, 150.0]})
    tripled = base * 3 + 2  # log1p(3x+2) - log1p(3y+2) == log1p(x) - log1p(y) when +1 scales too
    a = prepare_inputs(base, ["target_lag1"])["target_lag1"]
    b = prepare_inputs(tripled, ["target_lag1"])["target_lag1"]
    assert np.allclose(a, b)
