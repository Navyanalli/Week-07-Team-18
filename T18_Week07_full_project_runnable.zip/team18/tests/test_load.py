"""Unit tests for loading and cleaning NESO files."""

import pandas as pd
import pytest

from src.data.load import find_column, load_constraint_breakdown, load_day_ahead, snake


def test_snake_case_headers():
    assert snake("﻿Thermal Volume (MWh)") == "thermal_volume_mwh"


def test_find_column_requires_exactly_one_match():
    cols = ["date", "thermal_volume", "thermal_cost"]
    assert find_column(cols, "thermal", "volume") == "thermal_volume"
    with pytest.raises(KeyError):
        find_column(cols, "thermal")


def test_constraint_breakdown_combines_years_and_keeps_latest_duplicate(tmp_path):
    pd.DataFrame({"Date": ["2018-03-31"], "Thermal Volume": [-5], "Thermal Cost": [10]}).to_csv(
        tmp_path / "constraint-breakdown-2017-2018.csv", index=False)
    pd.DataFrame({"Date": ["2018-03-31", "2018-04-01"], "Thermal Volume": [-7, 3],
                  "Thermal Cost": [11, 2]}).to_csv(tmp_path / "constraint-breakdown-2018-2019.csv", index=False)
    d1 = load_constraint_breakdown(tmp_path)
    assert len(d1) == 2
    assert d1.loc[d1["date"] == "2018-03-31", "thermal_volume_signed"].item() == -7


def test_missing_folder_contents_raise(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_constraint_breakdown(tmp_path)


def test_day_ahead_cleaning_sentinel_duplicates_and_mixed_timestamps(tmp_path):
    pd.DataFrame({
        "Constraint Group": ["B6", "B6", "B6", "SC1"],
        "Date (GMT/BST)": ["2023-10-28T00:00", "2023-10-28T00:00:00", "2023-10-28T00:30:00", "2023-10-28T00:00"],
        "Limit (MW)": [5000, 5000, 99999, 0],
        "Flow (MW)": [-2500, -2500, 100, 50],
    }).to_csv(tmp_path / "da.csv", index=False)
    d3 = load_day_ahead(tmp_path)
    assert d3["timestamp_local"].notna().all()
    assert len(d3) == 3  # one duplicate removed
    assert d3["limit_mw"].isna().sum() == 2  # 99999 and 0 become missing
    b6 = d3[(d3["group"] == "B6") & (d3["timestamp_local"] == "2023-10-28 00:00")]
    assert b6["utilisation"].item() == pytest.approx(0.5)
