"""Data quality checks from the Test Plan. Each check returns PASS, WARN or FAIL.

A FAIL stops the pipeline; a WARN must be explained in the Data Management Plan.
"""

from __future__ import annotations

import pandas as pd

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"


def _row(dataset: str, check: str, status: str, detail: str) -> dict:
    return {"dataset": dataset, "check": check, "status": status, "detail": detail}


def check_constraint_breakdown(d1: pd.DataFrame) -> list[dict]:
    """Checks for the daily constraint breakdown (D1)."""
    out = []
    full = pd.date_range(d1["date"].min(), d1["date"].max(), freq="D")
    missing = full.difference(d1["date"])
    # a few missing days are dropped and logged (Test Plan); over 1% of days is a FAIL
    gap_status = PASS if len(missing) == 0 else (WARN if len(missing) <= 0.01 * len(full) else FAIL)
    out.append(_row("D1", "one row per day, no gaps", gap_status,
                    f"{len(d1)} days; {len(missing)} missing"
                    + (f" e.g. {missing[0].date()}" if len(missing) else "")))
    dup = int(d1["date"].duplicated().sum())
    out.append(_row("D1", "duplicate dates", PASS if dup == 0 else FAIL, f"{dup} duplicates"))
    na = int(d1["thermal_volume_signed"].isna().sum())
    out.append(_row("D1", "missing thermal volume", PASS if na == 0 else WARN, f"{na} missing"))
    v = d1["thermal_volume_signed"]
    out.append(_row("D1", "sign of thermal volume", WARN if (v < 0).any() else PASS,
                    f"{int((v < 0).sum())} negative, {int((v == 0).sum())} zero, "
                    f"{int((v > 0).sum())} positive days; min {v.min():,.0f}, max {v.max():,.0f}"))
    return out


def check_generation_mix(d2: pd.DataFrame) -> list[dict]:
    """Checks for the half-hourly generation mix (D2)."""
    out = []
    t = d2["DATETIME"]
    full = pd.date_range(t.min(), t.max(), freq="30min")
    gaps = len(full.difference(t))
    out.append(_row("D2", "no missing half-hours", PASS if gaps == 0 else WARN, f"{gaps} missing"))
    dup = int(t.duplicated().sum())
    out.append(_row("D2", "duplicate timestamps", PASS if dup == 0 else FAIL, f"{dup} duplicates"))
    num = d2.select_dtypes("number")
    neg_cols = [c for c in ["WIND", "WIND_EMB", "GENERATION", "SOLAR", "NUCLEAR", "GAS"]
                if c in num and (num[c] < 0).any()]
    out.append(_row("D2", "no negative generation", PASS if not neg_cols else WARN,
                    "none" if not neg_cols else f"negative in {neg_cols}"))
    for col in ["WIND", "GENERATION"]:
        na = int(d2[col].isna().sum()) if col in d2 else -1
        out.append(_row("D2", f"missing {col}", FAIL if na < 0 else (PASS if na == 0 else WARN),
                        "column absent" if na < 0 else f"{na} missing"))
    return out


def check_day_ahead(d3: pd.DataFrame) -> list[dict]:
    """Checks for the cleaned day-ahead flows and limits (D3)."""
    out = []
    dup = int(d3.duplicated(["group", "timestamp_local"]).sum())
    out.append(_row("D3", "unique (group, timestamp)", PASS if dup == 0 else FAIL, f"{dup} duplicates"))
    na_lim = int(d3["limit_mw"].isna().sum())
    out.append(_row("D3", "missing or sentinel limits", PASS if na_lim == 0 else WARN,
                    f"{na_lim} limits missing after cleaning"))
    groups = d3.groupby("date")["group"].nunique()
    out.append(_row("D3", "constraint groups per day", PASS if groups.nunique() == 1 else WARN,
                    f"{groups.min()}-{groups.max()} groups per day; {d3['group'].nunique()} in total"))
    out.append(_row("D3", "date range", PASS,
                    f"{d3['date'].min().date()} to {d3['date'].max().date()}"))
    return out


def run_all(d1: pd.DataFrame, d2: pd.DataFrame, d3: pd.DataFrame | None) -> pd.DataFrame:
    """Run every check and return one table of results."""
    rows = check_constraint_breakdown(d1) + check_generation_mix(d2)
    if d3 is not None:
        rows += check_day_ahead(d3)
    return pd.DataFrame(rows)
