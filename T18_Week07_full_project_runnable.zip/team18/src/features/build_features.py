"""Turn cleaned data into one row per UK day for modelling.

Rule against leakage: every feature in the row for day D uses data dated D-1 or
earlier, except calendar fields, which are known in advance.
"""

from __future__ import annotations

import holidays
import numpy as np
import pandas as pd

TZ = "Europe/London"


def to_uk_date(ts_utc: pd.Series) -> pd.Series:
    """Return the GB calendar date (midnight, no time zone) of UTC timestamps."""
    return ts_utc.dt.tz_convert(TZ).dt.tz_localize(None).dt.normalize()


def aggregate_generation_daily(
    d2: pd.DataFrame, min_periods: int = 46, max_gap: int = 2
) -> pd.DataFrame:
    """Aggregate half-hourly generation into daily statistics per UK day.

    Gaps of up to ``max_gap`` half-hours are interpolated. Days with fewer than
    ``min_periods`` half-hours are dropped (a normal day has 48; clock-change
    days have 46 or 50).
    """
    cols = [c for c in ["WIND", "WIND_EMB", "GENERATION"] if c in d2.columns]
    s = d2.set_index("DATETIME")[cols].sort_index()
    full = pd.date_range(s.index.min(), s.index.max(), freq="30min")
    s = s.reindex(full).interpolate(limit=max_gap, limit_area="inside")
    s["wind_total"] = s["WIND"] + s.get("WIND_EMB", 0)
    s["wind_share_pct"] = 100 * s["wind_total"] / s["GENERATION"]
    s["date"] = to_uk_date(pd.Series(s.index, index=s.index))
    g = s.groupby("date")
    daily = pd.DataFrame({
        "n_periods": g["wind_total"].count(),
        "wind_mean_mw": g["wind_total"].mean(),
        "wind_max_mw": g["wind_total"].max(),
        "wind_min_mw": g["wind_total"].min(),
        "wind_std_mw": g["wind_total"].std(),
        "wind_share_pct": g["wind_share_pct"].mean(),
        "total_gen_mean_mw": g["GENERATION"].mean(),
        "total_gen_max_mw": g["GENERATION"].max(),
    })
    daily = daily[daily["n_periods"] >= min_periods]
    daily["wind_to_demand"] = daily["wind_mean_mw"] / daily["total_gen_mean_mw"]
    return daily


def aggregate_day_ahead_daily(d3: pd.DataFrame) -> pd.DataFrame:
    """Daily summary of day-ahead boundary pressure: max and mean utilisation."""
    g = d3.groupby("date")["utilisation"]
    return pd.DataFrame({
        "da_util_max": g.max(),
        "da_util_mean": g.mean(),
        "da_share_over_90pct": d3.assign(hi=d3["utilisation"] >= 0.9).groupby("date")["hi"].mean(),
    })


def add_calendar(df: pd.DataFrame) -> pd.DataFrame:
    """Add calendar fields for each date (known in advance, so no leakage)."""
    idx = df.index
    gb = holidays.country_holidays("GB", subdiv="ENG", years=range(idx.year.min(), idx.year.max() + 1))
    df["day_of_week"] = idx.day_of_week
    df["month"] = idx.month
    df["is_weekend"] = (idx.day_of_week >= 5).astype(int)
    df["is_bank_holiday"] = [int(d in gb) for d in idx.date]
    doy = idx.day_of_year
    df["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    return df


def build_model_table(
    d1: pd.DataFrame,
    gen_daily: pd.DataFrame,
    da_daily: pd.DataFrame | None = None,
    lags: tuple[int, ...] = (1, 2, 7),
    windows: tuple[int, ...] = (7, 28),
) -> pd.DataFrame:
    """Build the daily modelling table (D4).

    ``target`` for day D is |thermal volume| on day D (MWh). All generation,
    day-ahead and target-history features are shifted so they use D-1 or
    earlier.
    """
    t = d1.set_index("date")[["thermal_volume_signed", "thermal_cost"]].sort_index()
    t = t.asfreq("D")
    t["target"] = t["thermal_volume_signed"].abs()
    past = gen_daily.reindex(t.index).shift(1).add_suffix("_lag1")
    t = t.join(past.drop(columns=["n_periods_lag1"]))
    for k in lags:
        t[f"target_lag{k}"] = t["target"].shift(k)
    for w in windows:
        t[f"target_roll{w}_mean"] = t["target"].shift(1).rolling(w, min_periods=max(2, w // 2)).mean()
    if da_daily is not None:
        t = t.join(da_daily.reindex(t.index).shift(1).add_suffix("_lag1"))
    return add_calendar(t)


def split_by_date(table: pd.DataFrame, split: dict) -> dict[str, pd.DataFrame]:
    """Chronological train / validation / test split with a one-day gap.

    Raises
    ------
    ValueError
        If the date ranges overlap or are out of order.
    """
    train_end = pd.Timestamp(split["train_end"])
    val_start, val_end = pd.Timestamp(split["val_start"]), pd.Timestamp(split["val_end"])
    test_start, test_end = pd.Timestamp(split["test_start"]), pd.Timestamp(split["test_end"])
    if not (train_end < val_start <= val_end < test_start <= test_end):
        raise ValueError(f"Split dates overlap or are out of order: {split}")
    return {
        "train": table.loc[:train_end],
        "val": table.loc[val_start:val_end],
        "test": table.loc[test_start:test_end],
    }
