"""Download the three NESO datasets into a dated snapshot folder.

Each run creates data/raw/snapshot_<YYYYMMDD>/<dataset>/ with every CSV in the
dataset and a metadata.json recording source URL, download time, size, rows
and SHA-256 checksum. Raw files are never edited afterwards.

Usage:
    python -m src.data.download_data            # all datasets
    python -m src.data.download_data --only constraint_breakdown
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import requests

from src.config import get_logger, load_config, project_path

log = get_logger(__name__)
TIMEOUT = 120


def list_csv_resources(api_url: str, package_id: str) -> list[dict]:
    """Return the CSV resources (name and url) of a NESO CKAN dataset.

    Raises
    ------
    RuntimeError
        If the API call fails or the dataset has no CSV files.
    """
    resp = requests.get(api_url, params={"id": package_id}, timeout=TIMEOUT)
    resp.raise_for_status()
    body = resp.json()
    if not body.get("success"):
        raise RuntimeError(f"NESO API returned an error for {package_id}: {body}")
    resources = [
        {"name": r.get("name", ""), "url": r["url"]}
        for r in body["result"]["resources"]
        if str(r.get("format", "")).lower() == "csv" or r["url"].lower().endswith(".csv")
    ]
    if not resources:
        raise RuntimeError(f"No CSV files found in dataset {package_id}")
    return resources


def sha256_of(path: Path) -> str:
    """Return the SHA-256 checksum of a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download_file(url: str, dest: Path) -> dict:
    """Stream a file to disk and return its metadata."""
    with requests.get(url, stream=True, timeout=TIMEOUT) as r:
        r.raise_for_status()
        with dest.open("wb") as f:
            for chunk in r.iter_content(1 << 20):
                f.write(chunk)
    with dest.open("rb") as f:
        rows = max(sum(1 for _ in f) - 1, 0)  # minus header line
    return {
        "file": dest.name,
        "source_url": url,
        "downloaded_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "bytes": dest.stat().st_size,
        "rows": rows,
        "sha256": sha256_of(dest),
    }


def download_all(only: str | None = None) -> Path:
    """Download every configured dataset into a new dated snapshot folder.

    Returns
    -------
    Path
        The snapshot folder that was written.
    """
    cfg = load_config()
    stamp = datetime.now().strftime("%Y%m%d")
    snapshot = project_path(f"{cfg['paths']['raw']}/snapshot_{stamp}")
    for name, info in cfg["neso"]["datasets"].items():
        if only and name != only:
            continue
        folder = snapshot / name
        folder.mkdir(parents=True, exist_ok=True)
        meta = {
            "dataset": name,
            "page": info["page"],
            "licence": "NESO Open Data Licence",
            "attribution": cfg["neso"]["attribution"],
            "files": [],
        }
        for res in list_csv_resources(cfg["neso"]["api"], info["package_id"]):
            filename = res["url"].rsplit("/", 1)[-1]
            log.info("Downloading %s / %s", name, filename)
            meta["files"].append(download_file(res["url"], folder / filename))
        (folder / "metadata.json").write_text(json.dumps(meta, indent=2))
        log.info("%s: %d files saved to %s", name, len(meta["files"]), folder)
    return snapshot


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="download one dataset by its config name")
    args = parser.parse_args()
    download_all(args.only)
