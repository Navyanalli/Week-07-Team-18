"""Tests for the hybrid model helpers (SARIMAX part and LSTM inputs)."""

import numpy as np
import pandas as pd
import pytest

pytest.importorskip("statsmodels")
pytest.importorskip("torch")

from src.models.hybrid import (  # noqa: E402
    EXOG_COLUMNS,
    WARMUP_DAYS,
    fit_sarimax,
    hybrid_inputs,
    make_exog,
    residuals,
    sarimax_forecast_log,
)


def toy_table(n=200, seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2023-01-01", periods=n, freq="D")
    wind = rng.uniform(1000, 10000, n)
    target = np.abs(2 * wind + rng.normal(0, 2000, n))
    t = pd.DataFrame({
        "target": target,
        "wind_mean_mw_lag1": np.roll(wind, 1),
        "is_weekend": (idx.day_of_week >= 5).astype(int),
        "is_bank_holiday": 0,
    }, index=idx)
    t["target_lag1"] = t["target"].shift(1)
    t["target_roll7_mean"] = t["target"].shift(1).rolling(7, min_periods=2).mean()
    return t


def test_exog_scaled_on_training_days_only():
    t = toy_table()
    train = t.index[:150]
    ex = make_exog(t, train)
    assert list(ex.columns) == EXOG_COLUMNS
    assert abs(ex.loc[train, "wind_mean_mw_lag1"].mean()) < 1e-9   # mean 0 on training days
    assert not ex.isna().any().any()                                  # constant column did not create NaN


def test_exog_missing_column_raises():
    t = toy_table().drop(columns="is_weekend")
    with pytest.raises(KeyError):
        make_exog(t, t.index[:150])


def test_forecast_does_not_use_the_same_day():
    """Changing the actual value on one day must not change that day's own forecast (no leakage)."""
    t = toy_table()
    train = t.index[:150]
    ex = make_exog(t, train)
    res = fit_sarimax(t, train, ex, seasonal_order=(0, 0, 0, 0))
    before = sarimax_forecast_log(res, t, ex)

    day = t.index[170]
    t2 = t.copy()
    t2.loc[day, "target"] *= 50
    after = sarimax_forecast_log(res, t2, ex)

    assert before.loc[day] == pytest.approx(after.loc[day])           # same day: unchanged
    assert before.loc[t.index[171]] != pytest.approx(after.loc[t.index[171]])  # next day: does change


def test_residuals_and_inputs():
    t = toy_table()
    train = t.index[:150]
    ex = make_exog(t, train)
    sx = sarimax_forecast_log(fit_sarimax(t, train, ex, seasonal_order=(0, 0, 0, 0)), t, ex)
    r = residuals(t, sx)
    assert r.iloc[:WARMUP_DAYS].isna().all()
    assert r.iloc[WARMUP_DAYS:].notna().all()

    x = hybrid_inputs(t, ["target_lag1", "wind_mean_mw_lag1"], sx, r)
    assert {"sarimax_resid_lag1", "sarimax_vs_level"} <= set(x.columns)
    assert x["sarimax_resid_lag1"].iloc[WARMUP_DAYS + 1] == pytest.approx(r.iloc[WARMUP_DAYS])  # shifted one day
