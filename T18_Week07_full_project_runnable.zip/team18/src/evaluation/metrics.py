"""Forecast metrics: MAE, RMSE, MASE, skill score and the Diebold-Mariano test."""

from __future__ import annotations

import math

import numpy as np


def _clean(y_true, y_pred) -> tuple[np.ndarray, np.ndarray]:
    a, b = np.asarray(y_true, dtype=float), np.asarray(y_pred, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"Length mismatch: {a.shape} vs {b.shape}")
    keep = ~(np.isnan(a) | np.isnan(b))
    if not keep.any():
        raise ValueError("No overlapping non-missing values to score")
    return a[keep], b[keep]


def mae(y_true, y_pred) -> float:
    """Mean absolute error."""
    a, b = _clean(y_true, y_pred)
    return float(np.mean(np.abs(a - b)))


def rmse(y_true, y_pred) -> float:
    """Root mean squared error."""
    a, b = _clean(y_true, y_pred)
    return float(np.sqrt(np.mean((a - b) ** 2)))


def mase(y_true, y_pred, y_train, m: int = 1) -> float:
    """Mean absolute scaled error.

    The scale is the MAE of the naive "value m steps ago" forecast on the
    training series, so MASE < 1 means better than persistence (m = 1).
    """
    tr = np.asarray(y_train, dtype=float)
    tr = tr[~np.isnan(tr)]
    if len(tr) <= m:
        raise ValueError("Training series too short for MASE")
    scale = np.mean(np.abs(tr[m:] - tr[:-m]))
    if scale == 0:
        raise ValueError("MASE scale is zero (constant training series)")
    return mae(y_true, y_pred) / scale


def skill_score(y_true, y_pred, y_baseline) -> float:
    """1 - MAE(model) / MAE(baseline); above 0 means better than the baseline."""
    return 1 - mae(y_true, y_pred) / mae(y_true, y_baseline)


def diebold_mariano(y_true, pred_a, pred_b) -> tuple[float, float]:
    """Diebold-Mariano test on absolute errors for one-step forecasts.

    Returns (statistic, two-sided p-value). A negative statistic means model A
    has smaller errors than model B.
    """
    a, pa, pb = (np.asarray(x, dtype=float) for x in (y_true, pred_a, pred_b))
    if not (a.shape == pa.shape == pb.shape):
        raise ValueError(f"Length mismatch: {a.shape}, {pa.shape}, {pb.shape}")
    keep = ~(np.isnan(a) | np.isnan(pa) | np.isnan(pb))  # same days for both forecasts
    if keep.sum() < 3:
        raise ValueError("Too few overlapping days for the Diebold-Mariano test")
    a, pa, pb = a[keep], pa[keep], pb[keep]
    d = np.abs(a - pa) - np.abs(a - pb)
    n = len(d)
    var = np.var(d, ddof=1) / n
    if var == 0:
        return 0.0, 1.0
    stat = float(np.mean(d) / math.sqrt(var))
    p = 2 * (1 - 0.5 * (1 + math.erf(abs(stat) / math.sqrt(2))))
    return stat, float(p)
