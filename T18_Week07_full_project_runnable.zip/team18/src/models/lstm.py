"""LSTM model (Model 1, neural network) for next-day thermal constraint volume.

Each training sample is a window of the last ``window`` days of inputs; the model
predicts the target for the last day of the window. The inputs in row D only use
information from day D-1 or earlier (``*_lag1`` features, ``target_lag1`` and
calendar fields), so the window never contains the value being predicted.

The target is modelled as log1p(volume) and the inputs are standardised with
statistics from the training period only.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch import nn

DEFAULT_FEATURES = [
    "target_lag1",
    "target_roll28_mean",
    "wind_mean_mw_lag1",
    "wind_max_mw_lag1",
    "wind_share_pct_lag1",
    "total_gen_mean_mw_lag1",
    "wind_to_demand_lag1",
    "doy_sin",
    "doy_cos",
    "is_weekend",
    "is_bank_holiday",
]
LOG_COLUMNS = ["target_lag1", "target_roll7_mean", "target_roll28_mean"]
LEVEL_COLUMN = "target_roll7_mean"  # mean of the previous 7 days (uses D-7 to D-1 only)


@dataclass
class Scaler:
    """Mean and standard deviation per column, fitted on training rows only."""

    mean: pd.Series
    std: pd.Series

    @classmethod
    def fit(cls, df: pd.DataFrame) -> Scaler:
        std = df.std().replace(0, 1.0)
        return cls(df.mean(), std)

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        return (df - self.mean) / self.std


def recent_level(table: pd.DataFrame) -> pd.Series:
    """log1p of the mean volume over the previous 7 days (the "recent level")."""
    return np.log1p(table[LEVEL_COLUMN].clip(lower=0))


def prepare_inputs(table: pd.DataFrame, features: list[str], relative: bool = True) -> pd.DataFrame:
    """Select the input columns and log-transform the volume-based ones.

    With ``relative=True`` volume inputs are expressed relative to the recent
    7-day level, so the model sees "higher or lower than usual" rather than raw
    size. This keeps inputs in a familiar range when the overall level of
    constraints changes (as it did from 2024-25).
    """
    missing = [c for c in features if c not in table.columns]
    if missing:
        raise KeyError(f"Columns missing from the model table: {missing}")
    x = table[features].astype(float).copy()
    level = recent_level(table) if relative else 0.0
    for c in LOG_COLUMNS:
        if c in x:
            x[c] = np.log1p(x[c].clip(lower=0)) - level
    return x


def make_target(table: pd.DataFrame, relative: bool = True) -> pd.Series:
    """Training target: log1p(volume), minus the recent 7-day level if relative."""
    y = np.log1p(table["target"])
    return y - recent_level(table) if relative else y


def to_mwh(z: np.ndarray, level: np.ndarray | float) -> np.ndarray:
    """Turn a (relative) log prediction back into MWh, never below zero."""
    return np.clip(np.expm1(np.asarray(z) + level), 0, None)


def make_sequences(
    x: pd.DataFrame, y: pd.Series, dates: pd.DatetimeIndex, window: int
) -> tuple[np.ndarray, np.ndarray, pd.DatetimeIndex]:
    """Build (samples, window, features) arrays ending on each date in ``dates``.

    A sample is kept only if its whole window and its target have no missing
    values. ``x`` and ``y`` must share one daily index.
    """
    xv = x.to_numpy(dtype=np.float32)
    yv = y.to_numpy(dtype=np.float32)
    pos = x.index.get_indexer(dates)
    xs, ys, kept = [], [], []
    for d, p in zip(dates, pos, strict=True):
        if p < window - 1:
            continue
        w = xv[p - window + 1: p + 1]
        if np.isnan(w).any() or np.isnan(yv[p]):
            continue
        xs.append(w)
        ys.append(yv[p])
        kept.append(d)
    if not xs:
        raise ValueError("No complete windows - check the window length and missing data")
    return np.stack(xs), np.array(ys, dtype=np.float32), pd.DatetimeIndex(kept)


class LSTMRegressor(nn.Module):
    """LSTM layers followed by a small dense head that outputs one value."""

    def __init__(self, n_features: int, hidden: int = 64, layers: int = 2, dropout: float = 0.2):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden, num_layers=layers, batch_first=True,
                            dropout=dropout if layers > 1 else 0.0)
        self.head = nn.Sequential(nn.Linear(hidden, 32), nn.ReLU(), nn.Dropout(dropout), nn.Linear(32, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.lstm(x)
        return self.head(out[:, -1, :]).squeeze(-1)


@dataclass
class LSTMConfig:
    window: int = 28
    hidden: int = 64
    layers: int = 2
    dropout: float = 0.2
    lr: float = 1e-3
    batch_size: int = 64
    max_epochs: int = 200
    patience: int = 15
    seed: int = 42


def set_seed(seed: int) -> None:
    """Fix random seeds so results can be reproduced."""
    np.random.seed(seed)
    torch.manual_seed(seed)


def train_lstm(
    x_train: np.ndarray, y_train: np.ndarray, x_val: np.ndarray, y_val: np.ndarray, cfg: LSTMConfig
) -> tuple[LSTMRegressor, pd.DataFrame]:
    """Train with Adam and Huber loss; stop early when validation loss stops improving.

    Returns the model with the best validation weights and the loss history.
    """
    set_seed(cfg.seed)
    model = LSTMRegressor(x_train.shape[2], cfg.hidden, cfg.layers, cfg.dropout)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    loss_fn = nn.HuberLoss()
    xt, yt = torch.from_numpy(x_train), torch.from_numpy(y_train)
    xv, yv = torch.from_numpy(x_val), torch.from_numpy(y_val)
    gen = torch.Generator().manual_seed(cfg.seed)
    best, best_state, wait, history = np.inf, None, 0, []
    for epoch in range(cfg.max_epochs):
        model.train()
        order = torch.randperm(len(xt), generator=gen)
        total = 0.0
        for i in range(0, len(xt), cfg.batch_size):
            idx = order[i: i + cfg.batch_size]
            opt.zero_grad()
            loss = loss_fn(model(xt[idx]), yt[idx])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += loss.item() * len(idx)
        model.eval()
        with torch.no_grad():
            val_loss = loss_fn(model(xv), yv).item()
        history.append({"epoch": epoch + 1, "train_loss": total / len(xt), "val_loss": val_loss})
        if val_loss < best - 1e-5:
            best, wait = val_loss, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            wait += 1
            if wait >= cfg.patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, pd.DataFrame(history)


def predict(
    model: LSTMRegressor, x: np.ndarray, y_mean: float, y_std: float, level: np.ndarray | float = 0.0
) -> np.ndarray:
    """Predict and convert back to MWh (never below zero).

    ``level`` is the recent 7-day log level for each sample when the model was
    trained with a relative target, otherwise 0.
    """
    model.eval()
    with torch.no_grad():
        z = model(torch.from_numpy(x)).numpy()
    return to_mwh(z * y_std + y_mean, level)
