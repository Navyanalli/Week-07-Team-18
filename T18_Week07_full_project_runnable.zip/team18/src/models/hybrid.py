"""Hybrid model: SARIMAX for the regular pattern, LSTM for SARIMAX's mistakes.

Idea from Zhang (2003): a linear model captures trend, weekly pattern and the
wind effect; a neural network then learns what is left (the residuals).

    hybrid forecast (log scale) = SARIMAX forecast + LSTM predicted residual

The LSTM part reuses everything in ``src.models.lstm``. This module only holds
the SARIMAX step and the extra LSTM inputs, so notebooks 03, 07 and 08 all use
exactly the same code.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX

from src.models.lstm import prepare_inputs, recent_level

EXOG_COLUMNS = ["wind_mean_mw_lag1", "is_weekend", "is_bank_holiday"]
ORDER = (1, 1, 1)
SEASONAL_ORDER = (1, 0, 1, 7)
WARMUP_DAYS = 30  # SARIMAX forecasts in the first month are unreliable, so their residuals are dropped


def make_exog(table: pd.DataFrame, train_idx: pd.DatetimeIndex, columns: list[str] = EXOG_COLUMNS) -> pd.DataFrame:
    """Outside inputs for SARIMAX, gaps filled and scaled with the training years only.

    Raises
    ------
    KeyError
        If a column is missing from the table.
    """
    missing = [c for c in columns if c not in table.columns]
    if missing:
        raise KeyError(f"Columns missing from the model table: {missing}")
    exog = table[columns].astype(float).ffill().bfill()
    std = exog.loc[train_idx].std().replace(0, 1.0)
    return (exog - exog.loc[train_idx].mean()) / std


def fit_sarimax(table: pd.DataFrame, train_idx: pd.DatetimeIndex, exog: pd.DataFrame,
                order: tuple = ORDER, seasonal_order: tuple = SEASONAL_ORDER):
    """Fit SARIMAX on log(1 + volume) for the training days only and return the fitted result."""
    y_log = np.log1p(table["target"])
    model = SARIMAX(y_log.loc[train_idx], exog=exog.loc[train_idx], order=order, seasonal_order=seasonal_order)
    return model.fit(disp=False)


def sarimax_forecast_log(result, table: pd.DataFrame, exog: pd.DataFrame) -> pd.Series:
    """One-step-ahead SARIMAX forecasts (log scale) for every day in the table.

    The parameters stay as fitted on the training years. Each day's forecast
    uses only actual values up to the day before, so there is no leakage.
    """
    y_log = np.log1p(table["target"])
    full = result.apply(y_log, exog=exog)
    return pd.Series(np.asarray(full.predict()), index=table.index, name="sarimax_log")


def residuals(table: pd.DataFrame, sx_log: pd.Series, warmup: int = WARMUP_DAYS) -> pd.Series:
    """What SARIMAX got wrong each day (log scale): actual minus forecast. First ``warmup`` days are missing."""
    resid = np.log1p(table["target"]) - sx_log
    resid.iloc[:warmup] = np.nan
    return resid.rename("residual")


def hybrid_inputs(table: pd.DataFrame, features: list[str], sx_log: pd.Series, resid: pd.Series) -> pd.DataFrame:
    """LSTM inputs for the hybrid: the usual features plus yesterday's SARIMAX mistake and SARIMAX's view.

    ``sarimax_resid_lag1`` is shifted by one day, so it only uses information from the day before.
    """
    x = prepare_inputs(table, features, relative=True)
    x["sarimax_resid_lag1"] = resid.shift(1)
    x["sarimax_vs_level"] = sx_log - recent_level(table)
    return x
